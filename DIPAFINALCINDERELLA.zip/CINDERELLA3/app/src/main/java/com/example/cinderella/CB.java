package com.example.cinderella;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class CB extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cb);
    }
}